package me.b3n3dkt.npc;

public enum Animation {
    HIT,
    TakeDamage,
    Effect,
    MagicDamage;
}
    